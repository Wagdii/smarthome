/*
 * Button.h
 *
 * Created: 6/26/2021 8:14:09 PM
 *  Author: karim
 */ 


#ifndef BUTTON_H_
#define BUTTON_H_

#include "Button_Config.h"
void Button0_Initialization(void);
uint8_t Button0_Read(void);
void Button1_Initialization(void);
uint8_t Button1_Read(void);
void Button2_Initialization(void);
uint8_t Button2_Read(void);

#endif /* BUTTON_H_ */